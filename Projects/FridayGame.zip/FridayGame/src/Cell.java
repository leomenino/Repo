public class Cell {
    private int row;
    private int col;
    private int[][] cellPosition = new int[row][col];
    // Rectangle[][] b = grid.getGrid();
    // Rectangle a = b[cursor.getX/Util.CELL_SIZE][cursor.getY/Util.CELL_SIZE];
    public Cell() {

    }

    public void painted(){
               

    }
}
