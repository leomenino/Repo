public enum GridDirection {
    UP,
    DOWN,
    LEFT,
    RIGHT;

}
