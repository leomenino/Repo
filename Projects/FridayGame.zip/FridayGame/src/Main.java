public class Main {
    public static void main(String[] args) {
    Grid grid =new Grid(40,40);
    Player player = new Player(1, 1);
    grid.init();
    player.createPlayer();
    //player.init();
    }
}
